gfortran ./Modulos/mod_prec.f90 ./Modulos/mod_funciones.f90 ./Modulos/mod_metodos.f90 parcial3_p1.f90 -o main.x
./main.x
gnuplot Lotka-Volterra.plt 
